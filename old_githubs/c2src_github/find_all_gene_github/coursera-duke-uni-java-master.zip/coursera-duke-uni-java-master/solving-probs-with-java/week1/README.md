The Java code for this course was compiled and run using BlueJay
