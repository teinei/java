# Java-Programming
Duke University Course in Coursera

## 課程教材參考
* http://www.dukelearntoprogram.com/course2/files.php


## Solving Problem With Software
###作業說明
* https://d396qusza40orc.cloudfront.net/phoenixassets/duke-java-programming/ProgrammingExercise-BatchGrayscale.pdf