# coursera-java-specialization-duke
5 course series:
This repository includes the quiz and project code that I have
accomplished through each course.

The courses are as follows:

1. Programming and the Web for Beginners (done)
2. Java Programming: Solving Problems with Software (done)
3. Java Programming: Arrays, Lists, and Structured Data (done)
4. Java Programming: Principles of Software Design (done)
5. Java Programming: A DIY Version of Netflix and Amazon Recommendation Engines (done)
