##### *Important*
To test the code, visit Duke's javascript environment by clicking [*here*](http://www.dukelearntoprogram.com/course1/example/index.php) (right click --> open new tab)

NOTE: The available images are on the bottom under "Available Images"
