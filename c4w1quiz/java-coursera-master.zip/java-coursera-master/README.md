# java-coursera
Stuff from Coursera's "Java Programming: An Introduction To Java" specialization classes. See the wiki for info on the seven step process of solving programming problems and the general workflow for fixing bugs.

Links to docs that I frequently reference while doing assignments:
* http://developer.android.com/reference/android/location/Location.html
* http://docs.oracle.com/javase/8/docs/api/
* https://commons.apache.org/proper/commons-csv/apidocs/index.html
* http://www.dukelearntoprogram.com/

Intellij links:
* https://www.jetbrains.com/idea/help/meet-intellij-idea.html
* https://www.youtube.com/channel/UC4ogdcPcIAOOMJktgBMhQnQ
