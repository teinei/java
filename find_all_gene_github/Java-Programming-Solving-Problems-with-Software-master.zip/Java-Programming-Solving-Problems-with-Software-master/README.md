# Java-Programming-Solving-Problems-with-Software
Assignments of Coursera Course "Java Programming: Solving Problems with Software".

##### Assignments:

**Week 1**: Iterables in Java; <em>It was too easy. I decided not to create a branch.</em> 

[**Week 2**](src/main/java/week2): Strings in Java;

[**Week 3**](src/main/java/week3): CSV Files and Basic Statistics in Java;

[**Week 4**](src/main/java/week4): MiniProject: Baby Names;

[**Tests**](src/test/java/): available for week 3 and week 4.

---
Good luck.
