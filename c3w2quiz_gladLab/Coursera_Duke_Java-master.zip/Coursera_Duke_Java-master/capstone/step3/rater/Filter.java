
public interface Filter {
	public boolean satisfies(String id);
}
