
/**
 * Write a description of TestSimple here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import edu.duke.*;

public class TestSimple{
     public void print() {  	
          Simple item = new Simple(3, "blue");     	
          System.out.println(item);
          System.out.println(item.mystery(5, "ho"));
     }      
}
