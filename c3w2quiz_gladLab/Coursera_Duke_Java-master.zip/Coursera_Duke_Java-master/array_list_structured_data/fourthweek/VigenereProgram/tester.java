
/**
 * Write a description of tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import edu.duke.*;
import java.util.*;

public class tester {
	//VigenereCipher[] vigenere;

	public void test(){
		VigenereCipher vigenere= new VigenereCipher();
		System.out.println("abcdefghijklm",0,3);
	}

}
