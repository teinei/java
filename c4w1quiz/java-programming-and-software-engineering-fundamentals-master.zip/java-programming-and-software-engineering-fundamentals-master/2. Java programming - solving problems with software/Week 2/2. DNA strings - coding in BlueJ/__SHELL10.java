
public class __SHELL10 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("/Users/Brienna/Documents/GitHub repositories/java-programming-coursera/Week 2/DNA strings - coding in BlueJ");
final TagFinder tagFinde1 = (TagFinder)__bluej_runtime_scope.get("tagFinde1");


tagFinde1.realTesting();

}}
